export type qrrequest = {
	url: string
	commander?: string,
	color?: string
}